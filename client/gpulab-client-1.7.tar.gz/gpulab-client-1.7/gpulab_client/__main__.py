import re
from os.path import expanduser
from time import sleep
from typing import Optional, Any, List

import requests
from cryptography import x509
from cryptography.hazmat.backends import default_backend

import sys

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
from cryptography.x509 import Certificate, ExtensionOID, SubjectAlternativeName
from requests.exceptions import SSLError

from gpulab.model.job_event import JobEvent, JobEventType

from gpulab.model.job import Job, JobState
from gpulab.model.slave_info import SlaveInfo

from gpulab_client.apiclient import GpuLabApiClient, JOB_DEFINITION, BadPemPasswordException, GPULAB_LOCALHOST_MODE, GpuLabApiLocalhostModeClient

import datetime
import click
import json
import ssl
import os
import pwd

from gpulab_client.util import td_format


# Info on other batch job systems:
#
#    Commands for various systems: https://slurm.schedmd.com/rosetta.pdf
#
#    Torque and slurm Job States:
#          https://slurm.schedmd.com/squeue.html
#          ttp://docs.adaptivecomputing.com/torque/4-1-3/Content/topics/commands/qstat.htm

API_CLIENT = 'client'
CERTFILE = 'cert_filename'


# modified version of:
# https://stackoverflow.com/questions/44247099/click-command-line-interfaces-make-options-required-if-other-optional-option-is
class NotRequiredIf(click.Option):
    def __init__(self, *args, **kwargs):
        self.not_required_if = kwargs.pop('not_required_if')
        assert self.not_required_if, "'not_required_if' parameter required"
        kwargs['help'] = (kwargs.get('help', '') +
                          ' NOTE: This argument is mutually exclusive with %s' %
                          self.not_required_if
                          ).strip()
        super(NotRequiredIf, self).__init__(*args, **kwargs)

    def handle_parse_result(self, ctx, opts, args):
        we_are_present = self.name in opts
        other_present = self.not_required_if in opts

        if other_present:
            if we_are_present:
                raise click.UsageError(
                    "Illegal usage: `%s` is mutually exclusive with `%s`" % (
                        self.name, self.not_required_if))
            else:
                self.prompt = None
        else:
            if not we_are_present:
                raise click.UsageError(
                    "Illegal usage: Either `%s` or `%s` must be specified" % (
                        self.name, self.not_required_if))

        return super(NotRequiredIf, self).handle_parse_result(
            ctx, opts, args)


# Date to string conversion for console
def _date_to_str(dt: Optional[datetime.datetime]) -> Optional[str]:
    if not dt:
        return None
    used_dt = dt - datetime.timedelta(microseconds=dt.microsecond)
    # change timezone to local
    used_dt = used_dt.astimezone(tz=None)
    return used_dt.isoformat()


def _print_table(headers: List[str], rows: List[List[Any]], add_vert_lines: bool = False, add_hor_lines: bool = False,
                 seperator : Optional[str] = None):
    rows_and_headers = list(rows)
    if headers:
        rows_and_headers.append(headers)
    widths = [max(map(len, map(str, col))) for col in zip(*rows_and_headers)]

    vert_hor_sep = seperator
    if not seperator:
        if add_vert_lines:
            seperator = ' | '
            vert_hor_sep = '-+-'
        else:
            seperator = '  '
            vert_hor_sep = seperator
    total_len = sum(widths) + ((len(widths)-1) * len(seperator))

    hor_line = ''
    if add_vert_lines:
        hor_line = vert_hor_sep.join((('-' * (width)) for val, width in zip(headers, widths)))
    else:
        hor_line = '-' * total_len

    if add_hor_lines:
        click.echo(hor_line)
    if headers:
        click.echo(seperator.join((val.ljust(width) for val, width in zip(headers, widths))))
        if add_hor_lines:
            click.echo(hor_line)
    for row in rows:
        click.echo(seperator.join((str(val).ljust(width) for val, width in zip(row, widths))))
        if add_hor_lines:
            click.echo(hor_line)


def _date_to_ago_str(dt: Optional[datetime.datetime]) -> Optional[str]:
    if not dt:
        return None
    used_dt = dt - datetime.timedelta(microseconds=dt.microsecond)
    # change timezone to local
    # used_dt = used_dt.astimezone(tz=None)
    # now_dt = datetime.datetime.now(datetime.timezone.utc)
    used_dt = used_dt
    now_dt = datetime.datetime.now(datetime.timezone.utc)
    diff_seconds = (now_dt - used_dt).total_seconds()
    if diff_seconds < 0:
        return '{} seconds in the future'.format(-diff_seconds)
    if diff_seconds < 60:
        return '{:.1f} seconds ago'.format(diff_seconds)
    if diff_seconds < 3600:
        return '{:.1f} minutes ago'.format(diff_seconds/60.0)
    if diff_seconds < 3600*24:
        return '{:.1f} hours ago'.format(diff_seconds/3600.0)
    return '{:.2f} days ago'.format(diff_seconds/(3600.0*24.0))


def _port_mapping_format(port_mappings: dict) -> str:
    try:
        res = []
        for port_mapping in port_mappings:
            res.append('{} -> {}'.format(port_mapping['container_port'], port_mapping['host_port']))
        return ', '.join(res)
    except:
        return 'Error processing port mappings: '+json.dumps(port_mappings)


CONTEXT_SETTINGS = dict(help_option_names=['-h', '--help'])

GPULAB_VERSION = '1.7'


def check_and_warn_version(ctx):
    client = ctx.obj[API_CLIENT]
    session = client.get_session()
    try:
        res = session.get(client.get_base_url() + "version", params={})
    except:
        click.secho(text="Could not check availability of new GPULab version",
                    err=True, nl=True, fg='red')
        return

    if not res.ok:
        click.secho(text="Could not check availability of new GPULab version",
                    err=True, nl=True, fg='red')
        return

    version_info = None
    try:
        version_info = res.json()
        latest_version = version_info['latest_client_version']
    except:
        click.secho(text="Error parsing availability of new GPULab version: {}".format(json.dumps(version_info)),
                    err=True, nl=True, fg='red')
        return

    if latest_version != GPULAB_VERSION:
        click.secho(text="A new version ({}) of gpulab-cli is available. (This is version {})"
                    .format(latest_version, GPULAB_VERSION),
                    err=True, nl=True, fg='yellow')


# Partial commands also match
class AliasedGroup(click.Group):
    def get_command(self, ctx, cmd_name):
        rv = click.Group.get_command(self, ctx, cmd_name)
        if rv is not None:
            return rv
        full_commands = list(self.list_commands(ctx))

        # first remove commands we don't want to have auto-completed
        dangerous_commands = ['rm', 'cancel']
        for dan in dangerous_commands:
            full_commands.remove(dan)
            if dan.startswith(cmd_name):
                return None  # avoid confusing matches, such as "r" matching release without this

        matches = [x for x in full_commands if x.startswith(cmd_name)]
        if not matches:
            return None
        elif len(matches) == 1:
            return click.Group.get_command(self, ctx, matches[0])
        ctx.fail('Too many matches: %s' % ', '.join(sorted(matches)))


def modify_usage_error():
    """
    a method to append the help menu to an usage error
    :return: None
    """

    from click._compat import get_text_stderr
    from click.utils import echo

    def show(self, file=None):
        if file is None:
            file = get_text_stderr()
        color = None
        if self.ctx is not None:
            color = self.ctx.color
        msg = self.format_message()
        if msg == 'Missing option "--cert".':
            echo('Error: "--cert" option (or GPULAB_CERT environment var) required.\n',
                 # 'For help, try:\n   gpulab-cli --help'
                 # '\nor:'
                 # '\n   gpulab-cli <command> --help\n\n'
                 file=file, color=color)
            if self.ctx is not None:
                echo(self.ctx.get_help() + '\n', file=file, color=color)
        else:
            if self.ctx is not None:
                echo(self.ctx.get_usage() + '\n', file=file, color=color)
            echo('Error: %s\n\nFor more help, try:\n   gpulab-cli --help' % msg, file=file, color=color)
        # import sys
        # sys.argv = [sys.argv[0]]  #not sure what this is supposed to do...
        # main_command()  #seems to cause recursion error
    click.exceptions.UsageError.show = show


@click.command(cls=AliasedGroup, invoke_without_command=True, context_settings=CONTEXT_SETTINGS)
# @click.group(invoke_without_command=True, context_settings=CONTEXT_SETTINGS)
@click.option("--cert", type=click.Path(readable=True), envvar='GPULAB_CERT', required=True, help='Login certificate')
@click.option("-p", "--password", type=click.STRING, help='Password associated with the login certificate')
@click.option("--dev", 'env_version', flag_value='dev', allow_from_autoenv=False, help='Use the GPULab development environment')
@click.option("--stable", 'env_version', flag_value='stable', allow_from_autoenv=False, help='Use the GPULab stable environment (default)')
@click.option("--servercert", type=click.Path(readable=True), envvar='GPULAB_SERVER_CERT', required=False,
              help='The file containing the servers (self-signed) certificate. Only required when the server uses '
                   'a self signed certificate.')
# See click.version_option(). note that similar arguments can be made with "click Eager Options"
@click.version_option(GPULAB_VERSION, message='%(version)s')
@click.pass_context
def cli(ctx: click.Context, cert, password, env_version: str, servercert):
    """GPULab client version 1.7

    \b
    This is the general help. For help with a specific command, try:
       gpulab-cli <command> --help

    \b
    Send bugreports, questions and feedback to: jfedbugreports@ilabt.imec.be

    \b
    Documentation: https://doc.ilabt.imec.be/ilabt/gpulab/
    Overview page: https://gpulab.ilabt.imec.be/
    Overview page (for --dev): https://dev.gpulab.ilabt.imec.be/
    """
    # These click feature switches make interaction with envvars more difficult. We need to handle it manually:
    #   (easier with boolean flags, but then we'd have -dev/--no-dev which is less nice)
    if env_version is None:
        if os.environ.get('GPULAB_STABLE') == 'True':
            env_version = 'stable'
        if os.environ.get('GPULAB_DEV') == 'True':
            env_version = 'dev'
        if os.environ.get('GPULAB_DEV') and os.environ.get('GPULAB_STABLE') == 'True':
            click.secho('WARNING: Both GPULAB_STABLE and GPULAB_DEV env vars are set to "True": Will fall back to stable.',
                        err=True, nl=True, fg='yellow')
        if env_version is None:
            env_version = 'stable'
    if env_version != 'dev' and env_version != 'stable':
        raise click.ClickException("Something went wrong with --dev/--stable flag: '{}'".format(env_version))

    dev = env_version == 'dev'

    if cert is not None and not os.path.isfile(cert):
        raise click.ClickException("The certificate file cannot be found ('{}').".format(cert))
    if ctx.invoked_subcommand is None:
        click.echo(cli.get_help(ctx))
    try:
        ctx.obj[API_CLIENT] = GpuLabApiClient(cert, password, dev, server_self_signed_cert=servercert)
        ctx.obj[CERTFILE] = cert
    except (ssl.SSLError, BadPemPasswordException):
        raise click.ClickException("The certificate is encrypted. You need to specify the correct password.")


@click.command(cls=AliasedGroup, invoke_without_command=True, context_settings=CONTEXT_SETTINGS)
# @click.group(invoke_without_command=True, context_settings=CONTEXT_SETTINGS)
@click.version_option(GPULAB_VERSION, message='%(version)s')
@click.pass_context
def localhost_mode_cli(ctx):
    """GPULab client version 1.7 (in LOCALHOST_MODE!)

    \b
    Send bugreports, questions and feedback to: jfedbugreports@ilabt.imec.be

    \b
    Documentation: https://doc.ilabt.imec.be/ilabt/gpulab/
    """
    if ctx.invoked_subcommand is None:
        click.echo(localhost_mode_cli.get_help(ctx))
    try:
        local_username = pwd.getpwuid(os.getuid()).pw_name  # this doesn't work on windows, but that's ok
        fixed_project_urn = os.environ[GPULAB_LOCALHOST_MODE]
        ctx.obj[API_CLIENT] = GpuLabApiLocalhostModeClient(local_username, fixed_project_urn)
        ctx.obj[CERTFILE] = None
        ctx.obj['project_urn'] = fixed_project_urn
        ctx.obj['project_name'] = re.sub(r'^.*\+project\+', '', fixed_project_urn)
    except (ssl.SSLError, BadPemPasswordException):
        raise click.ClickException("The certificate is encrypted. You need to specify the correct password.")


@click.command('submit', short_help="Submit a jobDefinition to run")
@click.option('-h', '--hold', is_flag=True, help="Do not queue job, immediately put it on hold")
@click.option('--wait-run', is_flag=True, help="Wait until job is running.")
@click.option('--wait-done', is_flag=True, help="Wait until job is done.")
@click.option('--email-run', is_flag=True, help="Send email when job is running.")
@click.option('--email-done', is_flag=True, help="Send email when job is done.")
# @click.option('-I','--interactive', is_flag=True, help="Interactive jobs. Wait for job ready, then connect terminal.")
@click.pass_context
def run_fixed_project(ctx, hold, wait_run, wait_done, email_run, email_done):
    actual_run(ctx, ctx.obj['project_name'], hold, wait_run, wait_done, email_run, email_done)


def _get_public_keys(ctx) -> List[str]:
    res = []

    # Add pubkey from login PEM
    if ctx.obj[CERTFILE]:
        with open(ctx.obj[CERTFILE], 'rb') as pemfile:
            pem_data = pemfile.read()
        cert = x509.load_pem_x509_certificate(pem_data, default_backend())  # type: Certificate
        public_key = cert.public_key()
        if public_key and isinstance(public_key, RSAPublicKey):
            public_key_openssh = public_key.public_bytes(
                serialization.Encoding.OpenSSH,
                serialization.PublicFormat.OpenSSH).decode("utf-8")
            # click.echo('public key in openssh format: {}'.format(public_key_openssh))
            res.append(public_key_openssh)

    # Add ~/.ssh/id_rsa.pub
    typical_pubkey_filename = expanduser("~/.ssh/id_rsa.pub")
    if os.path.isfile(typical_pubkey_filename):
        with open(typical_pubkey_filename, 'r') as opensshfile:
            public_key_openssh = opensshfile.read().strip(' \t\r\n')
            # click.echo('~/.ssh/id_rsa.pub: {}'.format(public_key_openssh))
            res.append(public_key_openssh)

    return res


# find the client's email address in the X509 cert
def _get_email_address(ctx) -> Optional[str]:
    try:
        # Get email from login PEM
        if ctx.obj[CERTFILE]:
            with open(ctx.obj[CERTFILE], 'rb') as pemfile:
                pem_data = pemfile.read()
            cert = x509.load_pem_x509_certificate(pem_data, default_backend())  # type: Certificate
            subj_alt_name = cert.extensions.get_extension_for_oid(
                ExtensionOID.SUBJECT_ALTERNATIVE_NAME)  # type: Optional[SubjectAlternativeName]
            if not subj_alt_name:
                return None
            emails = subj_alt_name.value.get_values_for_type(x509.RFC822Name)
            if emails:
                return emails[0]
    except Exception as e:
        raise e
        # return None
    return None


# variations seen for this commands:  "submit"  "batch"
@click.command('submit', short_help="Submit a jobDefinition to run")
# prompt MUST be false: otherwise, stdin will be used, and we need that later!
@click.option("--project", envvar='GPULAB_PROJECT', required=True, prompt=False)
# @click.option('-I','--interactive', is_flag=True, help="Interactive jobs. Wait for job ready, then connect terminal.")
@click.option('--wait-run', is_flag=True, help="Wait until job is running.")
@click.option('--wait-done', is_flag=True, help="Wait until job is done.")
@click.option('--email-queued', is_flag=True, help="Send email when job is queued.")
@click.option('--email-run', is_flag=True, help="Send email when job is running.")
@click.option('--email-done', is_flag=True, help="Send email when job is done.")
@click.option('--hold', is_flag=True, help="Do not queue job, immediately put it on hold")
@click.pass_context
def run(ctx, project, hold, wait_run, wait_done, email_queued, email_run, email_done):
    actual_run(ctx, project, hold, wait_run, wait_done, email_queued, email_run, email_done)


def actual_run(ctx, project, hold, wait_run, wait_done, email_queued, email_run, email_done):
    """Submit a docker image to run on a GPU node"""
    jobdef_raw = click.get_text_stream('stdin')

    jobdef = json.load(jobdef_raw)

    if JOB_DEFINITION not in jobdef:
        raise click.ClickException("Expected a '{}' element, but couldn't find one".format(JOB_DEFINITION))

    jobdef['project'] = project
    try:
        jobdef['ssh_pubkeys'] = _get_public_keys(ctx)
    except:
        click.secho('Error while trying to add public ssh key(s) to job (will continue without)',
                    err=True, nl=True, fg='red')

    if email_queued or email_run or email_done:
        client_email_address = _get_email_address(ctx)
        if not client_email_address:
            click.secho('Could not find your email address (will continue without email triggers)',
                        err=True, nl=True, fg='red')
        else:
            if email_queued:
                jobdef['emails_queue'] = [client_email_address]
            if email_run:
                jobdef['emails_run'] = [client_email_address]
            if email_done:
                jobdef['emails_end'] = [client_email_address]

    client = ctx.obj[API_CLIENT]
    s = client.get_session()
    params = {}
    if hold:
        params['hold'] = 'true'
    r = s.post(client.get_base_url() + "jobs", json=jobdef, params=params)

    if r.ok:
        job_id = r.text
        print(job_id)
    elif r.status_code == 403:
        raise click.ClickException("No permission to submit job. Did you specify a correct project?")
    else:
        raise click.ClickException("Job submission failed: {}".format(r.text))

    if wait_run or wait_done:
        actual_wait(ctx, job_id, wait_run, wait_done)


# queue has been merged as special case of "jobs"

# # variations seen for this commands:  "queue"  "stat"   "query"   "history"
# @click.command("queue", short_help="list queued jobs")
# @click.option('-u','--user', is_flag=True, help="Only jobs for the calling user")
# @click.option('-r','--raw', is_flag=True, help="Return JSON-objects")
# @click.pass_context
def queue(ctx, raw: bool, user: bool, always_add_running_jobs: bool,
          max_hours: Optional[int], max_count: Optional[int]):
    """Returns the list of queued jobs"""
    check_and_warn_version(ctx)

    client = ctx.obj[API_CLIENT]
    s = client.get_session()
    params = {}

    if user:
        if not client.username:
            raise click.ClickException("--user option caused internal error: could not find user")
        params['username'] = str(client.username)
        if always_add_running_jobs:
            params['other_user_running'] = True

    if not max_hours and user:
        max_hours = 7 * 24  # increase default if only for calling user
    if not max_count and user:
        max_count = 50    # increase default if only for calling user

    if max_hours:
        params['max_hours'] = max_hours
    if max_count:
        params['max_count'] = max_count

    r = s.get(client.get_base_url() + "jobs", params=params)

    if not r.ok:
        raise click.ClickException("Could not retrieve queued jobs: {}".format(r.text))

    try:
        jobs = r.json()
    except ValueError:
        raise click.ClickException("Could not parse server answer")

    if raw:
        print(json.dumps(jobs, indent=4))
    else:
        print("%-36s %-20.20s %-20.20s %-25.25s %-12.12s %-15.15s %-10.10s" % (
            "TASK ID", "NAME", "COMMAND", "CREATED", "USER", "PROJECT", "STATUS"))

        for j in jobs:
            assert j is not None
            job = Job.from_dict(j)

            def handle_none(none_or_str: Optional[str]):
                if not none_or_str:
                    return '***'
                else:
                    return none_or_str

            job_state = job.state.name if job.state else None

            print("%-36s %-20.20s %-20.20s %-25.25s %-12.12s %-15.15s %-10.10s" %
                  (j.get('uuid', None),
                   handle_none(job.name),
                   handle_none(job.get_command()),
                   handle_none(_date_to_str(job.created)),
                   handle_none(job.username),
                   handle_none(job.project),
                   handle_none(job_state)
                   ))


# variations seen for this commands:  "revoke" "abort" "cancel" "del" "rm"  "edit"
@click.command("rm", short_help="Remove job")
@click.argument('job_id', type=click.STRING)
@click.option('-f', '--finished', is_flag=True, help="Allow removing finished (and aborted) jobs")
@click.option('-r', '--real', is_flag=True, help="Really delete the Job (requires admin access). "
                                                 "If not specified, the job is only marked as deleted")
@click.option('-F', '--force', is_flag=True, help="Delete job in whatever state it is. (requires admin access)")
@click.pass_context
def rm(ctx, job_id, finished, real, force):
    if not real and force:
        raise click.ClickException("Incompatible options: --force requires --real")

    client = ctx.obj[API_CLIENT]
    s = client.get_session()
    params = {}
    if finished:
        params['finished'] = 'true'
    if real:
        params['real'] = 'true'
    if force:
        params['force'] = 'true'
    r = s.delete(client.get_base_url() + "jobs/" + job_id, params=params)

    if r.ok:
        print(job_id)
    else:
        raise click.ClickException("Error while revoking request: {}".format(r.text))


# variations seen for this commands:  "revoke" "abort" "cancel" "del" "rm"  "edit"
@click.command("cancel", short_help="Cancel running job")
@click.argument('job_id', type=click.STRING)
@click.pass_context
def cancel(ctx, job_id):
    client = ctx.obj[API_CLIENT]
    s = client.get_session()
    r = s.put("{}jobs/{}/state".format(client.get_base_url(), job_id), data='CANCELLED')

    if r.ok:
        print(job_id)
    else:
        raise click.ClickException("Error while cancelling job: {}".format(r.text))


# variations seen for this commands:  "revoke" "abort" "cancel" "del" "rm"  "edit"
@click.command("hold", short_help="Hold queued job(s). Status will change from QUEUED to ONHOLD")
@click.argument('job_id', required=False, type=click.STRING)
@click.option('-a', '--all', is_flag=True, help="Hold all jobs of the calling user")
@click.pass_context
def hold_job(ctx, job_id, all):
    if not job_id and not all:
        raise click.ClickException("Not enough options: --all or a <job_id> required")
    if job_id and all:
        raise click.ClickException("Incompatible options: Either --all or a <job_id> required, but not both")
    if all:
        raise click.ClickException("--all is not yet implemented")

    client = ctx.obj[API_CLIENT]
    s = client.get_session()
    r = s.put("{}jobs/{}/state".format(client.get_base_url(), job_id), data='ONHOLD')

    if r.ok:
        print(job_id)
    else:
        raise click.ClickException("Error while holding job: {}".format(r.text))


# variations seen for this commands:  "revoke" "abort" "cancel" "del" "rm"  "edit"
@click.command("release", short_help="Release held job(s). Status will change from ONHOLD to QUEUED")
@click.argument('job_id', required=False, type=click.STRING)
@click.option('-a', '--all', is_flag=True, help="Release all jobs of the calling user")
@click.pass_context
def release(ctx, job_id, all):
    if not job_id and not all:
        raise click.ClickException("Not enough options: --all or a <job_id> required")
    if job_id and all:
        raise click.ClickException("Incompatible options: Either --all or a <job_id> required, but not both")
    if all:
        raise click.ClickException("--all is not yet implemented")

    client = ctx.obj[API_CLIENT]
    s = client.get_session()
    r = s.put("{}jobs/{}/state".format(client.get_base_url(), job_id), data='QUEUED')

    if r.ok:
        print(job_id)
    else:
        raise click.ClickException("Error while releasing job: {}".format(r.text))


# variations seen for this commands:  "log" "tail"
@click.command("log", short_help="Retrieve a job's log")
@click.argument('job_id', type=click.STRING)
# @click.option('-t', '--tail', is_flag=True, help="receive only last bytes of the log")
@click.option('-f', '--follow', is_flag=True, help="Keep receiving data as it becomes available")
# @click.option('-r', '--raw', is_flag=True, help="Return JSON-objects")
# @click.option('--timestamps/--no-timestamps', help="Show timestamps", default=True)
@click.pass_context
def get_log(ctx, job_id, follow):
    # def get_logs(ctx, job_id, raw, timestamps):
    client = ctx.obj[API_CLIENT]  # type: Any[GpuLabApiLocalhostModeClient, GpuLabApiClient]
    s = client.get_session()  # type: requests.Session

    previous_end_byte = None
    while previous_end_byte is None or follow:
        # if follow, then keep requesting periodically (infinitely!), using range header
        headers = {}
        if previous_end_byte:
            headers['Range'] = 'bytes={}-'.format(previous_end_byte)
            sleep(1.0)

        with s.get("{}jobs/{}/log".format(client.get_base_url(), job_id), stream=True, headers=headers) as r:
            if not r.ok:
                raise click.ClickException("Error while fetching log for {}: {}".format(job_id, r.text))

            if r.status_code == 200 or r.status_code == 206:
                for line in r.iter_lines():
                    print(line.decode())

            if 'Content-Range' in r.headers:
                content_range = r.headers.get('Content-Range')  # format: "bytes {0}-{1}/{2}"
                match = re.match(r'bytes ([0-9]+)-([0-9]+)/([0-9]+)', content_range)
                previous_end_byte = int(match.group(2))
            else:
                previous_end_byte = int(r.headers.get('Content-Length'))


@click.command("debug",
               short_help="Retrieve a job's debug info. (Do not rely on the presence or format of this info. "
                          "It will never be stable between versions. If this has the only source of info you need, "
                          "ask the developers to expose that info in a different way!)")
@click.argument('job_id', type=click.STRING)
@click.option('-r', '--raw', is_flag=True, help="Return JSON-objects")
@click.pass_context
def get_debug(ctx, job_id, raw):
    client = ctx.obj[API_CLIENT]
    s = client.get_session()  # type: requests.Session

    with s.get("{}jobs/{}/debug".format(client.get_base_url(), job_id), stream=True) as r:
        if not r.ok:
            raise click.ClickException("Error while fetching events for {}: {}".format(job_id, r.text))

        try:
            events = r.json()
        except ValueError:
            raise click.ClickException("Could not parse server answer")

        if raw:
            print(json.dumps(events, indent=4))
        else:
            for e in events:
                assert e is not None
                event = JobEvent.from_dict(e)

                if event.type == JobEventType.STATUS_CHANGE:
                    print('{} STATE CHANGED -> {}'.format(_date_to_str(event.time), event.new_state.name))
                else:
                    print('{} LOG {}: {}'.format(_date_to_str(event.time), event.type.name, event.msg))


@click.command("clusters",
               short_help="Retrieve info about the available clusters. "
                          "If a cluster_id is specified, detailed info about the slaves of that cluster is shown.")
@click.argument('cluster_id', type=click.STRING, required=False)
@click.option('-r', '--raw', is_flag=True, help="Return JSON-objects")
@click.option('-a', '--all', is_flag=True, help="(if no <cluster_id>) Show all slave info")
@click.option('-n', '--no-lines', is_flag=True, help="Do not draw lines to seperate the columns")
@click.option('-s', '--short', is_flag=True, help="(if <cluster_id> provided) "
                                                  "Short summary (excluding some data)")
@click.pass_context
def get_slave_info(ctx, cluster_id, all, raw, short, no_lines):
    """Returns info for each cluster.

    When --short is used, slash-seperated numbers represent the 'free' and 'total' quantity for Workers, GPUs, CPUs and memory (format XX/YY)
    (for example: XX/YY means  now XX free, of YY in total)"""
    client = ctx.obj[API_CLIENT]
    s = client.get_session()  # type: requests.Session

    if cluster_id is None and not all:
        with s.get("{}clusters".format(client.get_base_url()), stream=True) as r:
            if not r.ok:
                raise click.ClickException("Error while fetching clusters: {}".format(r.text))

            try:
                cluster_infos = r.json()
            except ValueError:
                raise click.ClickException("Could not parse server answer")

            if raw:
                print(json.dumps(cluster_infos, indent=4))
            else:
                header = [ 'ID', 'GPU Type', 'Comment', 'Slaves', 'GPUs', 'CPUs' ]
                rows = []
                for cluster_info in cluster_infos:
                    assert cluster_info is not None
                    rows.append(['{} {}'.format(
                        cluster_info['cluster_id'],
                        cluster_info['version'] if 'version' in cluster_info else '?'),
                        ','.join(cluster_info['gpu_types']),
                        cluster_info['comment'],
                        cluster_info['slave_count'],
                        '{}/{}'.format(
                            cluster_info['gpu_available_count'],
                            cluster_info['gpu_total_count']),
                        '{}/{}'.format(
                            cluster_info['cpu_available_count'],
                            cluster_info['cpu_total_count'])
                    ])
                _print_table(header, rows, add_hor_lines=not no_lines, add_vert_lines=not no_lines)
    else:
        with s.get("{}slaves".format(client.get_base_url()), stream=True) as r:
            if not r.ok:
                raise click.ClickException("Error while fetching slaves: {}".format(r.text))

            try:
                slave_infos = r.json()
            except ValueError:
                raise click.ClickException("Could not parse server answer")

            if not all and cluster_id is not None:
                slave_infos = [ x for x in slave_infos if str(x['cluster_id']) == str(cluster_id) ]

            if raw:
                print(json.dumps(slave_infos, indent=4))
            else:
                if short:
                    header = [ 'Slave host', 'Cluster', 'Version', 'Workers', 'GPUs', 'CPUs', 'Memory (GB)' ]
                    rows = []
                    for si_dict in slave_infos:
                        assert si_dict is not None
                        slave_info = SlaveInfo.from_dict(si_dict)
                        rows.append([slave_info.slave_hostname,
                                     slave_info.cluster_id,
                                     slave_info.version,
                                     '{:d}/{:d}'.format(slave_info.worker_count-slave_info.worker_inuse, slave_info.worker_count),
                                     '{:d}/{:d}'.format(slave_info.gpu_count-slave_info.gpu_inuse, slave_info.gpu_count),
                                     '{:d}/{:d}'.format(slave_info.cpu_count-slave_info.cpu_inuse, slave_info.cpu_count),
                                     '{:>.2f}/{:<.2f}'.format((slave_info.system_memory_mb-slave_info.system_memory_inuse_mb)/1000,
                                                              slave_info.system_memory_mb/1000)
                                     ])
                    _print_table(header, rows, add_hor_lines=not no_lines, add_vert_lines=not no_lines)
                else:
                    print('*' * 80)
                    print('Full Cluster info (use --short for a summary)')
                    for si_dict in slave_infos:
                        assert si_dict is not None
                        slave_info = SlaveInfo.from_dict(si_dict)
                        print('*' * 80)
                        print('Host "{}"'.format(slave_info.slave_hostname))
                        print('Cluster {}'.format(slave_info.cluster_id))
                        print('Version "{}"'.format(slave_info.version))
                        print('            Free    | Total')
                        print('   Workers: {:<7d} | {:<7d}'.format(slave_info.worker_count-slave_info.worker_inuse,
                                                                   slave_info.worker_count))
                        print('   GPUs:    {:<7d} | {:<7d}'.format(slave_info.gpu_count-slave_info.gpu_inuse,
                                                                   slave_info.gpu_count))
                        print('   CPUs:    {:<7d} | {:<7d}'.format(slave_info.cpu_count-slave_info.cpu_inuse,
                                                                   slave_info.cpu_count))
                        print('   Memory:  {:<7.2f} | {:<7.2f} (GB)'.format(
                            (slave_info.system_memory_mb-slave_info.system_memory_inuse_mb)/1000,
                            slave_info.system_memory_mb/1000))
                        print('   GPU model: {}'.format(', '.join(slave_info.gpu_models)))
                        print('   CPU model: {}'.format(', '.join(slave_info.cpu_models)))
                        print('   CUDA version: {}'.format(slave_info.cuda_version_full))
                        print('   Updated: {} ({})'.format(_date_to_str(slave_info.last_update),
                                                           _date_to_ago_str(slave_info.last_update)))
                        print('   Comment: {}'.format(slave_info.comment))
                    print('*' * 80)


# variations seen for this commands:  "queue" "info" "query" "show" "stat" "status"
@click.command("jobs", short_help="Get info about one or more jobs")
@click.argument('job_id', type=click.STRING, required=False)
@click.option('-H', '--max-hours', required=False, type=click.INT,
              help="Show all jobs in the last X hours (default 12 (168 with -u), max 744 (=31 days))")
@click.option('-c', '--max-count', required=False, type=click.INT,
              help="Show no more than X jobs (default 10 (50 with -u), max 200)")
@click.option('-u', '--user', is_flag=True, help="Info on all jobs for the calling user + other user's running jobs")
@click.option('-U', '--strict-user', is_flag=True, help="Info on all jobs for the calling user (and no other user's jobs)")
@click.option('-r', '--raw', is_flag=True, help="Return JSON-object")
@click.option('-d', '--definition', is_flag=True, help="Show only the job definition (requires <job_id>)")
@click.pass_context
def get_info(ctx, job_id: str, raw: bool, user: bool, definition: bool,
             max_hours: Optional[int], max_count: Optional[int],
             strict_user: bool):
    if job_id and user:
        raise click.ClickException("Incompatible options: Either --user or a <job_id>, but not both.  (job_id={})".format(job_id))

    if definition and not job_id:
        raise click.ClickException("Incompatible options: --definition requires a <job_id>")

    if not job_id:
        return queue(ctx, raw, user or strict_user, not strict_user, max_hours, max_count)

    client = ctx.obj[API_CLIENT]
    s = client.get_session()  # type: requests.Session

    r = s.get(client.get_base_url() + "jobs/" + job_id)

    if r.ok:
        jobinfo = r.json()

        if raw:
            print(json.dumps(jobinfo, indent=4))
        else:
            job = Job.from_dict(jobinfo)

            if definition:
                print(json.dumps(job.nvdocker_data, indent=4))
            else:
                def handle_none(i: Optional[Any]) -> Any:
                    if i is None:
                        return '-'
                    else:
                        return i

                print("{:>15}: {}".format("Job ID", job.uuid))
                print("{:>15}: {}".format("Name", handle_none(job.name)))
                print("{:>15}: {}".format("Description", handle_none(job.get_description())))
                print("{:>15}: {}".format("Project", handle_none(job.project)))
                print("{:>15}: {}".format("Username", handle_none(job.username)))
                print("{:>15}: {}".format("Docker image", handle_none(job.get_docker_image_nopass())))
                print("{:>15}: {}".format("Command", handle_none(job.get_command())))

                status = job.state.name if job.state else None
                print("{:>15}: {}".format("Status", handle_none(status)))
                print("{:>15}: {}".format("Created", handle_none(_date_to_str(job.created))))
                print("{:>15}: {}".format("State Updated", handle_none(_date_to_str(job.state_updated))))
                print("{:>15}: {}".format("Queued", handle_none(_date_to_str(job.queue_time))))
                print("{:>15}: {}".format("Worker ID", handle_none(job.get_worker_id())))
                if job.get_worker_hostname():
                    print("{:>15}: {}".format("Worker Name", job.get_worker_hostname()))
                if job.get_port_mappings():
                    print("{:>15}: {}".format("Port Mappings", _port_mapping_format(job.get_port_mappings())))
                    if job.get_worker_dnsname():
                        print("{:>15}: {}".format("Worker Host", job.get_worker_dnsname()))
                if job.get_ssh_username() and job.get_worker_dnsname():
                    print("{:>15}: {}".format("SSH login:", 'ssh {}@{}'.format(job.get_ssh_username(),
                                                                               job.get_worker_dnsname())))
                print("{:>15}: {}".format("Started", handle_none(_date_to_str(job.get_start()))))
                duration = job.get_duration()
                print("{:>15}: {}".format("Duration", td_format(duration) if duration else "-"))
                print("{:>15}: {}".format("Finished", handle_none(_date_to_str(job.get_end()))))
                print("{:>15}: {}".format("Deadline", handle_none(_date_to_str(job.get_deadline()))))
    else:
        raise click.ClickException("Could not retrieve info for job '{}': {}".format(job_id, r.text))


@click.command("wait", short_help="Wait for a job to change state")
@click.argument('job_id', type=click.STRING)
@click.option('--wait-run', is_flag=True, help="Wait until job is running.",
              cls=NotRequiredIf, not_required_if='wait_done')
@click.option('--wait-done', is_flag=True, help="Wait until job is done.",
              cls=NotRequiredIf, not_required_if='wait_run')
@click.pass_context
def wait(ctx, job_id, wait_run, wait_done):
    actual_wait(ctx, job_id, wait_run, wait_done)


def actual_wait(ctx, job_id, wait_run, wait_done):
    client = ctx.obj[API_CLIENT]
    s = client.get_session()

    job_update_url = client.get_base_url() + "jobs/" + job_id

    sys.stdout.flush()
    sys.stderr.flush()

    outstream = sys.stderr

    prev_state = None
    prev_state_start_time = datetime.datetime.now(datetime.timezone.utc)

    start_wait_time = datetime.datetime.now(datetime.timezone.utc)

    # print('Wait line format: <absolute time> - <relative time> - message', file=sys.stderr)

    def now_localtz() -> datetime:
        return datetime.datetime.now().astimezone()

    def line_prefix(show_relative: bool = True):
        rel_time = datetime.datetime.now(datetime.timezone.utc) - start_wait_time
        rel_time_str = td_format(rel_time)
        needed_spaces = 10 - len(rel_time_str)
        if needed_spaces > 0:
            rel_time_str += ' ' * needed_spaces
        return '{:%Y-%m-%d %H:%M:%S %z} - {} - '.format(
            now_localtz(),
            rel_time_str if show_relative else (' ' * 10)
        )

    wait_line_prefix = (' ' * 39) + '  '

    prev_state_wait_time_pass = False

    if wait_run or wait_done:
        print(line_prefix(False)+'Waiting for Job to start running...', file=sys.stderr)
        queued = True
        print_requires_newline_first = False
        print_for_backspace_required = 0
        while queued:
            sys.stdout.flush()
            sys.stderr.flush()
            sleep(2)
            wait_time = datetime.datetime.now(datetime.timezone.utc) - start_wait_time
            r = s.get(job_update_url)
            if r.ok:
                jobinfo = r.json()
                job = Job.from_dict(jobinfo)
                if prev_state != job.state:
                    if print_requires_newline_first:
                        print(file=outstream)
                    print(line_prefix()+'Job is in state {}'
                          .format(job.state.name if job.state else 'None'),
                          file=outstream)
                    prev_state_start_time = datetime.datetime.now(datetime.timezone.utc)
                    print_requires_newline_first = False
                    print_for_backspace_required = 0
                else:
                    cur_state_time = datetime.datetime.now(datetime.timezone.utc) - prev_state_start_time
                    toprint = wait_line_prefix+'    state unchanged for {}'.format(td_format(cur_state_time))
                    print(('\b' * print_for_backspace_required)+toprint, file=outstream, end='')
                    print_for_backspace_required = len(toprint)
                    print_requires_newline_first = True

                outstream.flush()
                queued = job.state == JobState.QUEUED \
                         or job.state == JobState.TRANSFER \
                         or job.state == JobState.STARTING
                prev_state = job.state
            else:
                if print_requires_newline_first:
                    print_requires_newline_first = False
                    print(file=outstream)
                print(line_prefix()+'Error fetching job info. Give up waiting.', file=outstream)
                queued = False
                return
        prev_state_wait_time_pass = True
        if print_requires_newline_first:
            print_requires_newline_first = False
            print(file=outstream)
        print(line_prefix()+'Job is now running', file=outstream)

    if not prev_state_wait_time_pass:
        prev_state = None

    if wait_done:
        print_requires_newline_first = False
        print_for_backspace_required = 0
        print(line_prefix()+'Waiting for Job to finish...', file=outstream)
        # start_wait_time = datetime.datetime.now(datetime.timezone.utc)  # no new wait start for second wait
        running = True
        while running:
            sys.stdout.flush()
            outstream.flush()
            sleep(2)
            wait_time = datetime.datetime.now(datetime.timezone.utc) - start_wait_time
            r = s.get(job_update_url)
            if r.ok:
                jobinfo = r.json()
                job = Job.from_dict(jobinfo)
                if prev_state != job.state or prev_state_wait_time_pass:
                    if print_requires_newline_first:
                        print(file=outstream)
                    print(line_prefix()+'Job is in state {}'
                          .format(job.state.name if job.state else 'None'),
                          file=outstream)
                    if not prev_state_wait_time_pass:
                        prev_state_start_time = datetime.datetime.now(datetime.timezone.utc)
                    print_requires_newline_first = False
                    print_for_backspace_required = 0
                    prev_state_wait_time_pass = False
                else:
                    cur_state_time = datetime.datetime.now(datetime.timezone.utc) - prev_state_start_time
                    toprint = wait_line_prefix+'    state unchanged for {}'.format(td_format(cur_state_time))
                    print(('\b' * print_for_backspace_required)+toprint, file=outstream, end='')
                    print_for_backspace_required = len(toprint)
                    print_requires_newline_first = True

                running = job.state == JobState.TRANSFER \
                          or job.state == JobState.STARTING \
                          or job.state == JobState.RUNNING
                prev_state = job.state
            else:
                if print_requires_newline_first:
                    print_requires_newline_first = False
                    print(file=outstream)
                print(line_prefix()+'Error fetching job info. Give up waiting.', file=outstream)
                running = False
                return
        if print_requires_newline_first:
            print_requires_newline_first = False
            print(file=outstream)
        print(line_prefix()+'Job has finished', file=outstream)

    sys.stdout.flush()
    sys.stderr.flush()


@click.command("ssh", short_help="Log in to a Job's container using SSH.")
@click.argument('job_id', required=True, type=click.STRING)
@click.option('-s', '--show', is_flag=True, help="Do not login, just show the SSH command.")
@click.pass_context
def ssh(ctx, job_id, show):
    """Log in to a Job's container using SSH."""
    client = ctx.obj[API_CLIENT]
    s = client.get_session()  # type: requests.Session

    r = s.get(client.get_base_url() + "jobs/" + job_id)

    if r.ok:
        jobinfo = r.json()

        job = Job.from_dict(jobinfo)

        if not job.get_ssh_username() or not job.get_worker_dnsname():
            raise click.ClickException("No SSH info for job")

        if show:
            ssh_command = 'ssh -i {} {}@{}'.format(ctx.obj[CERTFILE],
                                                   job.get_ssh_username(),
                                                   job.get_worker_dnsname())
            click.echo(ssh_command)
        else:
            os.execvp('ssh', ['ssh', '-i', ctx.obj[CERTFILE], '{}@{}'.format(job.get_ssh_username(),
                                                                             job.get_worker_dnsname())])
    else:
        raise click.ClickException("Could not retrieve info for job '{}': {}".format(job_id, r.text))


cli.add_command(run)
# cli.add_command(queue)
cli.add_command(rm)
cli.add_command(cancel)
cli.add_command(hold_job)
cli.add_command(release)
cli.add_command(get_log)
cli.add_command(get_debug)
cli.add_command(get_slave_info)
cli.add_command(get_info)
cli.add_command(wait)
cli.add_command(ssh)

localhost_mode_cli.add_command(run_fixed_project)
# localhost_mode_cli.add_command(queue)
localhost_mode_cli.add_command(rm)
localhost_mode_cli.add_command(cancel)
localhost_mode_cli.add_command(hold_job)
localhost_mode_cli.add_command(release)
localhost_mode_cli.add_command(get_log)
localhost_mode_cli.add_command(get_debug)
localhost_mode_cli.add_command(get_slave_info)
localhost_mode_cli.add_command(get_info)
localhost_mode_cli.add_command(wait)
localhost_mode_cli.add_command(ssh)


def main():
    try:
        if GPULAB_LOCALHOST_MODE in os.environ:
            localhost_mode_cli(obj={}, auto_envvar_prefix="GPULAB")
        else:
            cli(obj={}, auto_envvar_prefix="GPULAB")
    except SSLError as e:
        s = str(e).lower()
        if 'certificate' in s and 'expired' in s:
            print('ERROR: The certificate in your login PEM has expired.')
        else:
            raise e


modify_usage_error()

if __name__ == "__main__":
    main()
