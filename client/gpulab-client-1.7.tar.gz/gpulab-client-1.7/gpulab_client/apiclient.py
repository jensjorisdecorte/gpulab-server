from cryptography.x509 import ExtensionOID
from requests.adapters import HTTPAdapter, DEFAULT_POOLBLOCK
from requests.packages.urllib3.util.ssl_ import create_urllib3_context
from requests.packages.urllib3 import PoolManager
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes

import requests
import os
import re

from gpulab.util.urn_util import URN

GPULAB_LOCALHOST_MODE = 'GPULAB_LOCALHOST_MODE'
GPULAB_API_BASE = 'GPULAB_API_BASE'
JOB_DEFINITION = 'jobDefinition'


class BadPemPasswordException(Exception):
    pass


class SSLClientCertAdapter(HTTPAdapter):
    def __init__(self, certfile, password, server_self_signed_cert=None):
        self.certfile = certfile
        self.password = password
        self.server_self_signed_cert = server_self_signed_cert

        super(SSLClientCertAdapter, self).__init__()


    def init_poolmanager(self, connections, maxsize, block=DEFAULT_POOLBLOCK, **pool_kwargs):
        context = create_urllib3_context()
        try:
            context.load_cert_chain(self.certfile, password=self.password)
        except OSError as e:
            if e.errno == 22 and e.strerror == 'Invalid argument': #TODO: this work only on linux, but the error is system dependent
                raise BadPemPasswordException(e)
            else:
                raise e

        pool_kwargs['ssl_context'] = context
        if self.server_self_signed_cert is not None:
            #ca_certs should work here, but it doesn't
            # print('trusting server certs in '+self.server_self_signed_cert)
            pool_kwargs['ca_certs'] = self.server_self_signed_cert
        # else:
        #     print('only trusting global root certs')

        super(SSLClientCertAdapter, self).init_poolmanager(connections, maxsize, block, **pool_kwargs)


class GpuLabApiClient(object):
    def __init__(self, certfile, password, dev=True, server_self_signed_cert=None):
        self.dev = dev

        session = requests.Session()

        #passing server_self_signed_cert should work here, but doesn't as passing ca_certs to init_poolmanager seems not to work
        session.mount(self.get_base_url(), SSLClientCertAdapter(certfile, password, server_self_signed_cert=server_self_signed_cert))

        #for now, just manually add the headers instead (to be removed when authentication webservice is in place)
        #session.headers['Fed4fire-Authenticated-User-Urn'] = "urn:publicid:IDN+wall2.ilabt.iminds.be+user+twalcari"
        #session.headers['Fed4fire-Authenticated-User-Projects'] = \
        #    "urn:publicid:IDN+wall2.ilabt.iminds.be+project+twalcari-test," + \
        #    "urn:publicid:IDN+wall2.ilabt.iminds.be+project+fgre"

        # passing server_self_signed_cert here does work
        if server_self_signed_cert is not None:
            session.verify = server_self_signed_cert

        self.session = session

        with open(certfile, 'r') as f:
            certcontent = f.read().encode('utf-8') # encode because load_pem_x509_certificate needs bytes
        cert = x509.load_pem_x509_certificate(certcontent, default_backend())
        ext = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
        urns = ext.value.get_values_for_type(x509.UniformResourceIdentifier)
        self.user_urn = urns[0]
        self.username = URN(urn=self.user_urn).name

    def get_base_url(self):
        if GPULAB_LOCALHOST_MODE in os.environ:
            return 'http://localhost:80/gpulab/api/v2.0/'
        if GPULAB_API_BASE in os.environ:
            return os.environ[GPULAB_API_BASE]
        elif self.dev:
            return "https://dev.gpulab.ilabt.imec.be/gpulab/api/v2.0/"
        else:
            return "https://gpulab.ilabt.imec.be/gpulab/api/v2.0/"

    def get_session(self) -> requests.Session:
        """
        :rtype: requests.Session
        :return: a session with the proper client certificate configured
        """
        return self.session

class GpuLabApiLocalhostModeClient(object):
    def __init__(self, local_username: str, fixed_project_urn: str):
        self.dev = False

        session = requests.Session()

        self.username = local_username
        self.user_urn = re.sub(r'\+project\+.*$', '+user+'+local_username, fixed_project_urn)

        #manually add the headers
        session.headers['Fed4fire-Authenticated'] = 'True'
        session.headers['Fed4fire-Authenticated-User-Urn'] = self.user_urn# "urn:publicid:IDN+wall2.ilabt.iminds.be+user+"+local_username
        session.headers['Fed4Fire-Authenticated-Project-Urns'] = fixed_project_urn

        self.session = session

    def get_base_url(self):
        return 'http://localhost:80/gpulab/api/v2.0/'

    def get_session(self) -> requests.Session:
        """
        :rtype: requests.Session
        :return: a session with the proper client certificate configured
        """
        return self.session
