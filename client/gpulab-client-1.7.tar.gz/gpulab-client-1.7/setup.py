
from setuptools import setup, find_packages

#requests 2.18.0 is required for "with session.get() as r:"  ("Response is now a context manager")
#         2.18.4 is what I use and works, so why not require it
#click 6.7 is what I use and works, so why not require it
#At least python 3.4 is required (not sure for which feature, but < 3.4 will certainly fail)

setup(
    name="gpulab-client",
    version="1.7",
    # Make sure to also update version number in gpulab_client/__main__.py  (three times!)

    description="GPULab client",
    long_description="GPULab client for submitting jobs to an GPULab instance",

    url="http://gpulab.ilabt.imec.be",

    author="Thijs Walcarius",
    author_email="thijs.walcarius@ugent.be",

    packages=["gpulab_client", "gpulab.model", "gpulab.util"],

    install_requires=["requests>=2.18.4", "click>=6.7",
                      "python-dateutil",
                      "cryptography"],
    python_requires='>=3.4',

    entry_points={
        'console_scripts': [
            'gpulab-cli=gpulab_client.__main__:main',  # command=package.module:function
        ],
    },


)



