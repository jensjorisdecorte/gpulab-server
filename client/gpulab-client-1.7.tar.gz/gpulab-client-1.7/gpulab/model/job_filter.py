from typing import Optional, List

from gpulab.model.job import JobState, _int_or_none


class JobFilter:
    def __init__(self,
                 version: Optional[str],
                 cluster_id: Optional[int] = None,
                 max_system_memory_mb: Optional[int] = None,
                 max_gpu_count: Optional[int] = None,
                 max_cpu_count: Optional[int] = None,
                 allowed_states: Optional[List[JobState]] = None, # [JobState.QUEUED] is a common value  [] and None mean don't filter
                 username: Optional[str] = None,
                 other_user_running: bool = False,
                 project_name: Optional[str] = None,
                 max_duration_s: Optional[int] = None,
                 slave_cuda_version: Optional[int] = None,  # Only major cuda version should be passed
                 slave_gpu_models: Optional[List[str]] = None):
        self.version = version  #dev or stable
        self.allowed_states = allowed_states # if allowed_states else None
        self.cluster_id = cluster_id
        self.max_gpu_count = _int_or_none(max_gpu_count)
        self.max_cpu_count = _int_or_none(max_cpu_count)
        self.max_system_memory_mb = _int_or_none(max_system_memory_mb)
        self.username = username
        self.other_user_running = other_user_running
        self.project_name = project_name
        self.max_duration_s = _int_or_none(max_duration_s)
        self.slave_cuda_version = slave_cuda_version
        self.slave_gpu_models = [] if slave_gpu_models is None else slave_gpu_models

    @classmethod
    def forSlave(cls,
                 version: str,
                 cluster_id: int,
                 max_system_memory_mb: int,
                 max_gpu_count: Optional[int] = 1,
                 max_cpu_count: Optional[int] = 1,
                 slave_cuda_version: Optional[int] = None,
                 slave_gpu_models: Optional[List[str]] = None) -> 'JobFilter':
        """typical JobFilter used by slave to search a Job to execute"""
        return cls(
            version=version,
            cluster_id=cluster_id,
            max_system_memory_mb=max_system_memory_mb,
            max_gpu_count=max_gpu_count,
            max_cpu_count=max_cpu_count,
            allowed_states=[JobState.QUEUED],
            slave_cuda_version=slave_cuda_version,
            slave_gpu_models=slave_gpu_models
        )

    @classmethod
    def forPending(cls,
                   version: str) -> 'JobFilter':
        """typical JobFilter used to find all Pending Jobs"""
        return cls(
            version=version,
            allowed_states=[JobState.QUEUED]
        )

    @classmethod
    def noFilter(cls):
        return cls(
            version=None,
            allowed_states=[]
        )

    def __str__(self):
        return '%s(%s)' % (
            type(self).__name__,
            ', '.join('%s=%s' % item for item in vars(self).items())
        )


# {
#     "jobDefinition": {
#         "name": "Iterativenet",
#         "description": "hello world",
#         "clusterId": 129,
#         "dockerImage": "gpulab.ilabt.imec.be:5000/sample:nvidia-smi",
#         "jobType": "BATCH",
#         "command": "",
#         "resources": {
#             "gpus": 1,
#             "systemMemory": 32768,
#             "cpuCores": 2
#         },
#         "jobDataLocations": [ ],
#         "portMappings": [ ]
#     }
# }