import re

import pytest
from gpulab.master.job_controller import is_bad_job_id, is_full_job_id, is_partial_job_id


def test_is_bad_job_id1():
    assert not is_bad_job_id('4542bde0-0bf3-11e8-a116-67343def24ba')
    assert not is_bad_job_id('4542BDE0-0BF3-11E8-A116-67343DEF24BA')
    assert not is_bad_job_id('4542BDE0-0bF3-11e8-A116-67343Def24BA')
    assert     is_bad_job_id('4542bde0-0bf3-11e8-a116-67343def24b')
    assert     is_bad_job_id('4542bde0')
    assert     is_bad_job_id('4542bde0-0bf3-11e8-a116-67343def24bac')
    assert     is_bad_job_id('4542bde0-0bf3-11e8-a11667343def24ba')
    assert     is_bad_job_id('4542bde0-0bf3-11e8-a116-67343def24bX')
    assert     is_bad_job_id('454xbde0-0bf3-11e8-a116-67343def24ba')
    assert     is_bad_job_id('4542bde0-0bf3-11e -a116-67343def24ba')
    assert     is_bad_job_id('4542bde00bf311e8a11667343def24ba')
    # assert     is_bad_job_id('4542bde-00bf3-11e8-a116-67343def24ba') # todo bad UUID, but not yet detected

def test_is_full_job_id():
    assert     is_full_job_id('4542bde0-0bf3-11e8-a116-67343def24ba')
    assert     is_full_job_id('4542BDE0-0BF3-11E8-A116-67343DEF24BA')
    assert     is_full_job_id('4542BDE0-0bf3-11E8-a116-67343DeF24bA')
    assert not is_full_job_id('4542bde0-0bf3-11e8-a116-67343def24b')
    assert not is_full_job_id('4542bde0')
    assert not is_full_job_id('4542bde0-0bf3-11e8-a116-67343def24bac')
    assert not is_full_job_id('4542bde0-0bf3-11e8-a11667343def24ba')
    assert not is_full_job_id('4542bde0-0bf3-11e8-a116-67343def24bX')
    assert not is_full_job_id('454xbde0-0bf3-11e8-a116-67343def24ba')
    assert not is_full_job_id('4542bde0-0bf3-11e -a116-67343def24ba')
    assert not is_full_job_id('4542bde00bf311e8a11667343def24ba')
    # assert     is_full_job_id('4542bde-00bf3-11e8-a116-67343def24ba')  # todo bad UUID, but not yet detected

def test_is_partial_job_id():
    assert not is_partial_job_id('4542bde0-0bf3-11e8-a116-67343def24ba')
    assert not is_partial_job_id('4542BDE0-0BF3-11E8-A116-67343DEF24BA')
    assert     is_partial_job_id('4542bde0-0bf3-11e8-a116-67343def24b')
    assert     is_partial_job_id('a')
    assert     is_partial_job_id('4')
    assert     is_partial_job_id('4542bde0')
    assert     is_partial_job_id('4542bde0-0bf3')
    assert     is_partial_job_id('4542bde0-0bf3-')
    assert     is_partial_job_id('4542BDE0')
    assert     is_partial_job_id('4542BDe0')
    assert not is_partial_job_id('4542bde0-0bf3-11e8-a116-67343def24bac')
    # assert not is_partial_job_id('4542bde0-0bf3-11e8-a11667343def24ba')  # todo not a partial UUID, but not yet detected
    assert not is_partial_job_id('4542bde0-0bf3-11e8-a116-67343def24bX')
    assert not is_partial_job_id('454xbde0-0bf3-11e8-a116-67343def24ba')
    assert not is_partial_job_id('4542bde0-0bf3-11e -a116-67343def24ba')
    # assert not is_partial_job_id('4542bde00bf311e8a11667343def24ba')  # todo not a partial UUID, but not yet detected
    # assert     is_partial_job_id('4542bde-00bf3-11e8-a116-67343def24ba')  # todo not a partial UUID, but not yet detected
