import datetime
import re
from enum import Enum
from typing import Dict, Optional, Any, List, Union

import dateutil.parser

NVDATA_JOBDEFINITION = "jobDefinition"
NVDATA_USERNAME = "username"
NVDATA_PROJECT = "project"

RUN_DETAIL_SLAVE_HOSTNAME = 'slaveHostname'
RUN_DETAIL_SLAVE_DNSNAME = 'slaveDnsName'
RUN_DETAIL_GPU_IDS = 'gpuIds'
RUN_DETAIL_CPU_IDS = 'cpuIds'
RUN_DETAIL_WORKER_ID = 'workerId'
RUN_DETAIL_CLUSTER_ID = 'clusterId'
RUN_DETAIL_PORT_MAPPINGS = 'portMappings'
RUN_DETAIL_START_DATE = 'startDate'
RUN_DETAIL_END_DATE = 'endDate'
RUN_DETAIL_DEADLINE_DATE = 'deadlineDate'
RUN_DETAIL_NOTIFY_DATE = 'notifyDate'  # last time the user was notified about this job (about how long it is running)
RUN_DETAIL_SSH_USERNAME = 'sshUsername'

DOCKER_IMAGE_USERPASS_PATTERN = re.compile('([a-zA-Z0-9_+-]*):([^@]*)@([^@]*)')

class JobState(Enum):
    ONHOLD = 'On Hold'               # On hold, not planned to run at this time (not in queue)
    QUEUED = 'Queued'                # Available to run, waiting in queue
    CANCELLED = 'Cancelled'          # Cancelled during run (due to user request)
    TRANSFER = 'Transferring'        # Being sent to worker
    STARTING = 'Starting'            # Received by worker, setup in progress, not yet running
    RUNNING = 'Running'              # Running on worker
    FINISHED = 'Finished'            # Run completed
    DELETED = 'Deleted'              # Marked as deleted. This causes it to be ignored in "queue" view
    FAILED = 'Failed'                # Failure due to job definition problem, system problems, or other.

def _int_or_none(val: Optional[Any]) -> Optional[int]:
    return int(val) if val is not None else None

class Job:
    def __init__(self,
                 uuid: Optional[str],
                 name: str,
                 state: JobState,
                 nvdocker_data: Optional[Dict],
                 username: str,
                 project: str,
                 created: datetime.datetime,
                 state_updated: datetime.datetime,
                 queue_time: Optional[datetime.datetime],  # last time the job was put in the queue
                 gpulab_version: str,
                 run_details: Dict,
                 ssh_pubkeys: List[str],
                 emails_queue: List[str],
                 emails_run: List[str],
                 emails_end: List[str]):
        # naive times not allowed
        assert queue_time is None or queue_time.tzinfo is not None
        assert created is None or created.tzinfo is not None
        assert state_updated is None or state_updated.tzinfo is not None

        self.uuid = uuid
        self.id = uuid   #id and uuid are synonyms for Job
        self.name = name
        self.state = state
        self.nvdocker_data = nvdocker_data  # dict with "jobDefinition" element (which contains the interesting dict)
        self.username = username
        self.project = project
        self.created = created
        self.state_updated = state_updated
        self.queue_time = queue_time
        self.gpulab_version = gpulab_version
        # self.run_details : Dict = run_details if run_details is not None else {}
        # self.ssh_pubkeys : List[str] = ssh_pubkeys if ssh_pubkeys is not None else []
        # self.emails_queue : List[str] = emails_queue if emails_queue is not None else []
        # self.emails_run : List[str] = emails_run if emails_run is not None else []
        # self.emails_end : List[str] = emails_end if emails_end is not None else []
        # Annotations like above not supported before 3.6
        self.run_details = run_details if run_details is not None else {}
        self.ssh_pubkeys = ssh_pubkeys if ssh_pubkeys is not None else []
        self.emails_queue = emails_queue if emails_queue is not None else []
        self.emails_run = emails_run if emails_run is not None else []
        self.emails_end = emails_end if emails_end is not None else []

    def _get_job_def_attr(self, attr_name: str) -> Any:
        if self.nvdocker_data is None \
                or not NVDATA_JOBDEFINITION in self.nvdocker_data \
                or not attr_name in self.nvdocker_data[NVDATA_JOBDEFINITION]:
            return None
        return self.nvdocker_data[NVDATA_JOBDEFINITION][attr_name]

    def _get_job_run_detail_attr(self, attr_name: str) -> Optional[Any]:
        if self.run_details is None \
                or not attr_name in self.run_details:
            return None
        return self.run_details[attr_name]

    def _set_job_run_detail_attr(self, attr_name: str, new_value: Optional[Any]) -> None:
        if self.run_details is None:
            return
        if new_value is None:
            if attr_name in self.run_details:
                del self.run_details[attr_name]
        else:
            self.run_details[attr_name] = new_value

    def _get_job_def_attr_attr(self, attr_level1_name: str, attr_level2_name: str) -> Any:
        if self.nvdocker_data is None \
                or not NVDATA_JOBDEFINITION in self.nvdocker_data \
                or not attr_level1_name in self.nvdocker_data[NVDATA_JOBDEFINITION]:
            return None
        level1_attr = self.nvdocker_data[NVDATA_JOBDEFINITION][attr_level1_name]
        if level1_attr is None \
                or not attr_level2_name in level1_attr:
            return None
        return level1_attr[attr_level2_name]

    # nvdata jobDefinition getters

    def get_name(self) -> str:
        res = self._get_job_def_attr('name')
        assert self.name == res
        return res

    def get_description(self) -> str:
        return self._get_job_def_attr('description')

    def get_requested_cluster_id(self) -> int:
        return self._get_job_def_attr('clusterId')

    def get_docker_image(self) -> Optional[str]:
        return self._get_job_def_attr('dockerImage')

    def get_docker_image_nopass(self) -> Optional[str]:
        if self._get_job_def_attr('dockerImage'):
            res = self._get_job_def_attr('dockerImage')
            match = DOCKER_IMAGE_USERPASS_PATTERN.match(res)
            if match:
                return "{}:XXXX@{}".format(match.group(1), match.group(3))
            else:
                return res
        else:
            return None

    def get_job_type(self) -> str:
        return self._get_job_def_attr('jobType')

    def get_command(self) -> str:
        return self._get_job_def_attr('command')

    def get_resources_gpus(self) -> int:
        res = _int_or_none(self._get_job_def_attr_attr('resources', 'gpus'))
        return res

    def get_resources_system_memory(self) -> int:
        res = _int_or_none(self._get_job_def_attr_attr('resources', 'systemMemory'))
        return res

    def get_resources_cpu_cores(self) -> int:
        res = _int_or_none(self._get_job_def_attr_attr('resources', 'cpuCores'))
        return res

    def get_resources_gpu_model(self) -> Union[List[str], str]:
        res = self._get_job_def_attr_attr('resources', 'gpuModel')
        return res

    def get_resources_gpu_model_likepatterns(self) -> List[str]:
        res = self._get_job_def_attr_attr('resources', 'gpuModel')
        if res is None:
            return []
        if isinstance(res, str):
            return ['%{}%'.format(res)]
        if hasattr(res, "__getitem__") or hasattr(res, "__iter__"): # Some type of iterable/List
            return list(map(lambda r: '%{}%'.format(r), res))
        raise ValueError('unsupported resources.gpuModel type: {}'.format(type(res)))

    def get_resources_min_cuda_version(self) -> int:
        res = _int_or_none(self._get_job_def_attr_attr('resources', 'minCudaVersion'))
        return res

    def get_job_data_locations(self) -> List:
        return self._get_job_def_attr('jobDataLocations')

    def get_requested_port_mappings(self) -> List:
        return self._get_job_def_attr('portMappings')

    # run_details getters

    def get_worker_hostname(self) -> str:
        return self._get_job_run_detail_attr(RUN_DETAIL_SLAVE_HOSTNAME)

    def get_worker_dnsname(self) -> str:
        return self._get_job_run_detail_attr(RUN_DETAIL_SLAVE_DNSNAME)

    def get_gpu_ids(self) -> List[str]:
        return self._get_job_run_detail_attr(RUN_DETAIL_GPU_IDS)

    def get_cpu_ids(self) -> List[str]:
        return self._get_job_run_detail_attr(RUN_DETAIL_CPU_IDS)

    def get_worker_id(self) -> int:
        return self._get_job_run_detail_attr(RUN_DETAIL_WORKER_ID)

    def get_cluster_id(self) -> int:
        return self._get_job_run_detail_attr(RUN_DETAIL_CLUSTER_ID)

    def get_port_mappings(self) -> List:
        return self._get_job_run_detail_attr(RUN_DETAIL_PORT_MAPPINGS)

    def get_ssh_username(self) -> List:
        return self._get_job_run_detail_attr(RUN_DETAIL_SSH_USERNAME)

    def get_start(self) -> Optional[datetime.datetime]:
        s = self._get_job_run_detail_attr(RUN_DETAIL_START_DATE)
        if s is None:
            return None
        else:
            return dateutil.parser.parse(s)

    def get_duration(self) -> Optional[datetime.timedelta]:
        start = self._get_job_run_detail_attr(RUN_DETAIL_START_DATE)
        end = self._get_job_run_detail_attr(RUN_DETAIL_END_DATE)
        if start is None:
            return None
        else:
            start = dateutil.parser.parse(start)
        if end is None:
            end = datetime.datetime.now(datetime.timezone.utc)
        else:
            end = dateutil.parser.parse(end)
        assert end.tzinfo is not None, 'end is naive "{}"'.format(self._get_job_run_detail_attr(RUN_DETAIL_END_DATE))
        assert start.tzinfo is not None, 'start is naive "{}"'.format(self._get_job_run_detail_attr(RUN_DETAIL_START_DATE))
        return end - start

    def get_queue_duration(self) -> Optional[datetime.timedelta]:
        start = self.queue_time
        end = self._get_job_run_detail_attr(RUN_DETAIL_START_DATE)
        if start is None:
            return None
        if end is None:
            end = datetime.datetime.now(datetime.timezone.utc)
        else:
            end = dateutil.parser.parse(end)
        assert end.tzinfo is not None, 'end is naive "{}"'.format(self._get_job_run_detail_attr(RUN_DETAIL_START_DATE))
        assert start.tzinfo is not None, 'start is naive "{}"'.format(self.queue_time)
        return end - start

    def get_end(self) -> Optional[datetime.datetime]:
        s = self._get_job_run_detail_attr(RUN_DETAIL_END_DATE)
        if s is None:
            return None
        else:
            return dateutil.parser.parse(s)

    def get_last_notify_date(self) -> Optional[datetime.datetime]:
        s = self._get_job_run_detail_attr(RUN_DETAIL_NOTIFY_DATE)
        if s is None:
            return None
        else:
            return dateutil.parser.parse(s)

    def set_last_notify_date(self, notify_date: Optional[datetime.datetime]) -> None:
        notify_date_str = notify_date.isoformat() if notify_date is not None else None
        self._set_job_run_detail_attr(RUN_DETAIL_NOTIFY_DATE, notify_date_str)

    def get_deadline(self) -> Optional[datetime.datetime]:
        s = self._get_job_run_detail_attr(RUN_DETAIL_DEADLINE_DATE)
        if s is None:
            return None
        else:
            return dateutil.parser.parse(s)

    # example:
    # "jobDefinition": {
    #      "name": "Iterativenet",
    #      "description": "hello world",
    #      "clusterId": 129,
    #      "dockerImage": "gpulab.ilabt.imec.be:5000/sample:nvidia-smi",
    #      "jobType": "BATCH",
    #      "command": "",
    #      "resources": {
    #          "gpus": 1,
    #          "systemMemory": 32768,
    #          "cpuCores": 2
    #      },
    #      "jobDataLocations": [ ],
    #      "portMappings": [ ]
    #  }

    def __repr__(self):
        return 'GpuLabJob %s: %s' % (self.name, self.uuid)

    def __eq__(self, rhs):
        return (
                self.uuid == rhs.uuid and
                type(self) == type(rhs))

    def full_equal(self, rhs):
        return (
                self.uuid == rhs.uuid and
                self.name == rhs.name and
                self.state == rhs.state and
                self.nvdocker_data == rhs.nvdocker_data and
                self.username == rhs.username and
                self.project == rhs.project and
                self.created == rhs.created and
                self.state_updated == rhs.state_updated and
                self.gpulab_version == rhs.gpulab_version and
                self.run_details == rhs.run_details and
                self.ssh_pubkeys == rhs.ssh_pubkeys and
                type(self) == type(rhs))

    def sanitized_copy(self) -> 'Job':
        """copy with removed confidential data"""
        run_details_sancopy = { }
        if RUN_DETAIL_SLAVE_HOSTNAME in self.run_details:
            run_details_sancopy[RUN_DETAIL_SLAVE_HOSTNAME] = self.run_details[RUN_DETAIL_SLAVE_HOSTNAME]
        if RUN_DETAIL_SLAVE_DNSNAME in self.run_details:
            run_details_sancopy[RUN_DETAIL_SLAVE_DNSNAME] = self.run_details[RUN_DETAIL_SLAVE_DNSNAME]
        if RUN_DETAIL_START_DATE in self.run_details:
            run_details_sancopy[RUN_DETAIL_START_DATE] = self.run_details[RUN_DETAIL_START_DATE]
        if RUN_DETAIL_END_DATE in self.run_details:
            run_details_sancopy[RUN_DETAIL_END_DATE] = self.run_details[RUN_DETAIL_END_DATE]
        if RUN_DETAIL_DEADLINE_DATE in self.run_details:
            run_details_sancopy[RUN_DETAIL_DEADLINE_DATE] = self.run_details[RUN_DETAIL_DEADLINE_DATE]
        if RUN_DETAIL_NOTIFY_DATE in self.run_details:
            run_details_sancopy[RUN_DETAIL_NOTIFY_DATE] = self.run_details[RUN_DETAIL_NOTIFY_DATE]

        copy = Job(
            uuid=self.uuid,
            name=self.name,
            state=self.state,
            nvdocker_data=None, # self.nvdocker_data,
            username=self.username,
            project=self.project,
            created=self.created,
            state_updated=self.state_updated,
            queue_time=self.queue_time,
            gpulab_version=self.gpulab_version,
            run_details=run_details_sancopy,
            ssh_pubkeys=[], # no need for others to see pubkeys, even though it can't really harm
            emails_queue=[],
            emails_run=[],
            emails_end=[]
        )
        return copy

    def to_dict(self) -> dict:
        res = dict()
        res['uuid'] = self.uuid
        res['name'] = self.name
        res['state'] = self.state.name if self.state is not None else None
        res['nvdocker_data'] = self.nvdocker_data
        res['username'] = self.username
        res['project'] = self.project
        res['created'] = self.created.isoformat() if self.created is not None else None
        res['state_updated'] = self.state_updated.isoformat() if self.state_updated is not None else None
        res['queue_time'] = self.queue_time.isoformat() if self.queue_time is not None else None
        res['gpulab_version'] = self.gpulab_version
        res['run_details'] = self.run_details
        res['ssh_pubkeys'] = self.ssh_pubkeys
        res['emails_queue'] = self.emails_queue
        res['emails_run'] = self.emails_run
        res['emails_end'] = self.emails_end
        return res

    @classmethod
    def from_dict(cls, d: dict):
        return cls(
            uuid=d['uuid'],
            name=d['name'],
            state=JobState[d['state']] if 'state'in d and d['state'] else None,
            nvdocker_data=d['nvdocker_data'],
            username=d['username'],
            project=d['project'],
            created=dateutil.parser.parse(d['created']) if 'created' in d and d['created'] else None,
            state_updated=dateutil.parser.parse(d['state_updated']) if 'state_updated' in d and d['state_updated'] else None,
            queue_time=dateutil.parser.parse(d['queue_time']) if 'queue_time' in d and d['queue_time'] else None,
            gpulab_version=d['gpulab_version'],
            run_details=d['run_details'],
            ssh_pubkeys=d['ssh_pubkeys'] if 'ssh_pubkeys' in d else None,
            emails_queue=d['emails_queue'] if 'emails_queue' in d else None,
            emails_run=d['emails_run'] if 'emails_run' in d else None,
            emails_end=d['emails_end'] if 'emails_end' in d else None
        )

# >>> import json
# >>> class ComplexEncoder(json.JSONEncoder):
# ...     def default(self, obj):
# ...         if isinstance(obj, complex):
# ...             return [obj.real, obj.imag]
# ...         # Let the base class default method raise the TypeError
# ...         return json.JSONEncoder.default(self, obj)
# ...
# >>> json.dumps(2 + 1j, cls=ComplexEncoder)
