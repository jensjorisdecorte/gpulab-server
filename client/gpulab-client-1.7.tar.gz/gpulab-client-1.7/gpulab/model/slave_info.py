import datetime
import dateutil.parser

from typing import Optional, List, Union

class SlaveInfo:
    def __init__(self,
                 version: str,
                 slave_hostname: str,
                 cluster_id: Union[int, str],

                 gpu_models: List[str],
                 cpu_models: List[str],

                 worker_count: int,
                 system_memory_mb: int,
                 gpu_count: int,
                 cpu_count: int,

                 worker_inuse: int,
                 system_memory_inuse_mb: int,
                 gpu_inuse: int,
                 cpu_inuse: int,

                 cuda_version_full: str,

                 last_update: Optional[datetime.datetime] = None,
                 comment: Optional[str] = None):
        self.version = version
        self.slave_hostname = slave_hostname
        self.cluster_id = str(cluster_id)

        self.gpu_models = gpu_models
        self.cpu_models = cpu_models

        self.worker_count = worker_count        
        self.system_memory_mb = system_memory_mb
        self.gpu_count = gpu_count
        self.cpu_count = cpu_count
        
        self.worker_inuse = worker_inuse        
        self.system_memory_inuse_mb = system_memory_inuse_mb
        self.gpu_inuse = gpu_inuse
        self.cpu_inuse = cpu_inuse

        self.cuda_version_full = cuda_version_full

        self.last_update = last_update
        self.comment = comment

        # No naive datetimes
        assert self.last_update is None or self.last_update.tzinfo is not None

    def to_dict(self) -> dict:
        res = dict()
        res['version'] = self.version
        res['slave_hostname'] = self.slave_hostname
        res['cluster_id'] = self.cluster_id
        res['gpu_models'] = self.gpu_models
        res['cpu_models'] = self.cpu_models
        res['worker_count'] = self.worker_count
        res['system_memory_mb'] = self.system_memory_mb
        res['gpu_count'] = self.gpu_count
        res['cpu_count'] = self.cpu_count
        res['worker_inuse'] = self.worker_inuse
        res['system_memory_inuse_mb'] = self.system_memory_inuse_mb
        res['gpu_inuse'] = self.gpu_inuse
        res['cpu_inuse'] = self.cpu_inuse
        res['cuda_version_full'] = self.cuda_version_full
        if self.last_update:
            assert self.last_update is None or self.last_update.tzinfo is not None
            res['last_update'] = self.last_update.isoformat()
        if self.comment:
            res['comment'] = self.comment
        return res

    @classmethod
    def from_dict(cls, d: dict):
        return cls(
            d['version'],
            d['slave_hostname'],
            d['cluster_id'],
            d['gpu_models'],
            d['cpu_models'] if 'cpu_models' in d else [],
            d['worker_count'],
            d['system_memory_mb'],
            d['gpu_count'],
            d['cpu_count'],
            d['worker_inuse'],
            d['system_memory_inuse_mb'],
            d['gpu_inuse'],
            d['cpu_inuse'],
            d['cuda_version_full'] if 'cuda_version_full' in d else 'unknown',
            dateutil.parser.parse(d['last_update']) if 'last_update'in d and d['last_update'] else None,
            d['comment'] if 'comment' in d else None
        )
